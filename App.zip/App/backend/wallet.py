from fastapi import APIRouter, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from .models import User, Wallet
from .schemas import UserCreate, DepositWithdraw
from .database import async_session

router = APIRouter()

@router.post("/users")
async def create_user(user: UserCreate):
    async with async_session() as session:
        new_user = User(name=user.name)
        session.add(new_user)
        await session.commit()
        await session.refresh(new_user)
        return new_user

@router.get("/users")
async def get_users():
    async with async_session() as session:
        result = await session.execute(select(User))
        return result.scalars().all()

@router.post("/wallet/deposit")
async def deposit(wallet: DepositWithdraw):
    async with async_session() as session:
        wallet_entry = await session.execute(select(Wallet).where(Wallet.user_id == wallet.user_id))
        wallet_entry = wallet_entry.scalar_one_or_none()
        if not wallet_entry:
            raise HTTPException(status_code=404, detail="Wallet not found")
        wallet_entry.balance += wallet.amount
        await session.commit()
        return {"new_balance": wallet_entry.balance}

@router.post("/wallet/withdraw")
async def withdraw(wallet: DepositWithdraw):
    async with async_session() as session:
        wallet_entry = await session.execute(select(Wallet).where(Wallet.user_id == wallet.user_id))
        wallet_entry = wallet_entry.scalar_one_or_none()
        if not wallet_entry:
            raise HTTPException(status_code=404, detail="Wallet not found")
        if wallet_entry.balance < wallet.amount:
            raise HTTPException(status_code=400, detail="Insufficient funds")
        wallet_entry.balance -= wallet.amount
        await session.commit()
        return {"new_balance": wallet_entry.balance}